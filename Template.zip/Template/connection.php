<?php
$conn = mysqli_connect("localhost", "root", "", "Template") or die("could not connect" . mysqli_error($conn) ) ;
?>
